<footer class="main-footer">
    <strong>Copyright &copy;  {{ date("Y") }} <a href="https://adminlte.io">Acme Mine</a>.</strong>
    All rights reserved.
  </footer>
</div>