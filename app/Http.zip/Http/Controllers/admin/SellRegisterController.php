<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Quc;
use App\Models\SellRegister;
use App\Models\User;
use App\Models\Vendor_Managment;
use App\Models\Wip;
use App\Models\WorkInProgressStep3;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\Facades\DataTables;

class SellRegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $vendors = Vendor_Managment::get();
        $wip = Wip::get();
        $users = User::get();
        $quc = Quc::get();
        if($request->ajax()) {
            $sell_register = SellRegister::with("wip","parties","users","quc")->orderBy('id', 'DESC')->select('*');
            return DataTables::of($sell_register)->addIndexColumn()->make(true);
        }
        return view('admin.sell_register.index',compact("wip","vendors","users","quc"));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $inputs = $request->except('_token');
        $inputs["mine_id"] = Session::get("mine_id");
        if($disaptch = SellRegister::create($inputs)) {
            return redirect()->back()->with('message',config('constant.add_sell_register'));
        }
        return redirect()->back()->with('error',config('constant.somthing_wrong'));
    }
    
     public function getSellAmount(Request $request){
        $sell_register = SellRegister::find($request->id);
        return response()->json($sell_register);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        // $vendors = Vendor_Managment::get();
        // $wip = Wip::get();
        // $users = User::get();
        // $quc = Quc::get();
        $sell_register = SellRegister::find($id);
        // return response()->json(view('admin.sell_register.edit', compact('sell_register','wip','vendors','users','quc'))->render());
        return response()->json(["sell_register" => $sell_register]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $inputs = $request->except('_token','_method');
        if($disaptch = SellRegister::where("id",$id)->update($inputs)) {
            return redirect()->back()->with('message',config('constant.update_sell_register'));
        }
        return redirect()->back()->with('error',config('constant.somthing_wrong'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if(SellRegister::where("id",$id)->delete()) {
            return response()->json(['message' => config('constant.delete_sell_register')]);
        }
        return response()->json(['error' => config('constant.somthing_wrong')]);
    }

    public function getStock(Request $request){
        $stockItems = WorkInProgressStep3::where("wip_id",$request->wipId)
            ->sum("no_of_pieces");
        $sellQty = SellRegister::where("wip_no",$request->wipId)->sum("sell_qty");
        $rem_qty = $stockItems - $sellQty;
            return response()->json(['status' => true,'data'=>$rem_qty>0?$rem_qty:0]);
    }
}
